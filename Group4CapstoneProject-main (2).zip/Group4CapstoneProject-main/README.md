# Group3CapstoneProject
Side link
https://docs.google.com/presentation/d/13UKDn5uYPmOmi_wly7smwIS4mwURQq2o_BY5S233gs8/edit?usp=sharing
